# Kep Dental Clinic — App Android (WebView)

នេះជា project កូដសម្រាប់ធ្វើជា App Android (.apk) ដែលបើកគេហទំព័រ
https://sites.google.com/view/dentalkep/home ដូចជា App ធម្មតា (គ្មាន address bar, គ្មាន browser)។

ខ្ញុំ (Claude) មិនអាច compile ជាឯកសារ .apk ដោយផ្ទាល់នៅទីនេះបានទេ ព្រោះមិនមាន Android SDK/Gradle
នៅក្នុង environment នេះ។ ប៉ុន្តែមានវិធីងាយៗ ២ យ៉ាង ដើម្បីទទួលបាន .apk ពី project នេះ ដោយឥតគិតថ្លៃ៖

## វិធីទី១ (ងាយបំផុត — មិនចាំបាច់ដំឡើងអ្វីទេ): GitHub Actions

1. បង្កើត account GitHub ឥតគិតថ្លៃ (github.com) បើមិនទាន់មាន។
2. បង្កើត repository ថ្មី ឈ្មោះអ្វីក៏បាន (ឧ. `kep-dental-app`), ជា **Public** ឬ **Private** ក៏បាន។
3. Upload ឯកសារទាំងអស់ក្នុង zip នេះទៅ repository នោះ (អាច drag-and-drop ក្នុងគេហទំព័រ GitHub បាន
   ក្នុងទំព័រ "Add file → Upload files").
4. ចូលទៅ tab **Actions** នៅលើ repository — វានឹង build APK ដោយស្វ័យប្រវត្តិ (ចំណាយពេលប្រហែល ២-៣ នាទី)។
5. នៅពេល build រួច ចុចចូល workflow run នោះ រួចទាញយក (download) artifact ឈ្មោះ
   **KepDental-debug-apk** — ក្នុងនោះនឹងមានឯកសារ `app-debug.apk`។
6. ចម្លងឯកសារ `.apk` នោះទៅទូរស័ព្ទ Android ហើយចុចដំឡើង (ត្រូវបើក "Install from unknown sources"
   ក្នុង Settings សិន)។

## វិធីទី២: Android Studio (បើមានកុំព្យូទ័រខ្លាំង)

1. ទាញយក Android Studio ឥតគិតថ្លៃពី developer.android.com
2. File → Open → ជ្រើសរើស folder `KepDentalApp` នេះ
3. រង់ចាំ Gradle sync
4. Build → Build Bundle(s)/APK(s) → Build APK(s)
5. APK នឹងនៅក្នុង `app/build/outputs/apk/debug/app-debug.apk`

## ចំណាំ

- App នេះគ្រាន់តែជា "WebView wrapper" — វាបើក website ដដែលនៅក្នុង app។ ប្រសិនបើអ្នកកែប្រែ
  គេហទំព័រ Google Sites ឬឯកសារ HTML ដើម App ក៏នឹងបង្ហាញការផ្លាស់ប្ដូរនោះដែរ ដោយមិនចាំបាច់ build
  ជាថ្មីទេ។
- ប្រសិនបើចង់ដាក់ App logo ផ្ទាល់ខ្លួន ត្រូវបន្ថែម icon files ទៅក្នុង `app/src/main/res/mipmap-*`
  ហើយបន្ថែម `android:icon="@mipmap/ic_launcher"` ទៅក្នុង AndroidManifest.xml។
- Package name បច្ចុប្បន្ន: `com.kephospital.dental` — អាចប្ដូរបានតាមចង់។
- APK ដែល build ដោយវិធីទី១/២ គឺជា **debug APK** ។ បើចង់ដាក់លើ Google Play Store
  ត្រូវ sign ជា release APK ដោយប្រើ keystore ផ្ទាល់ខ្លួន — ប្រាប់ខ្ញុំបាន ខ្ញុំអាចពន្យល់ជំហានបន្ថែម។
